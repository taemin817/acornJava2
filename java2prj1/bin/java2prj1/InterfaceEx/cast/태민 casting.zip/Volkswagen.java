package java2prj1.InterfaceEx.cast;

public interface Volkswagen {
	public String including(Object son);
}
